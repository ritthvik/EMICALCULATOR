# Car-EMI-Calculator-AIDL-Service-App

An android application developed for open ended project.

Used Methods : AIDL and Service.
